package fr.formation.projection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Spring auto-generated test case.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class ProjectionApplicationTests {

    /**
     * Spring auto-generated test.
     */
    @Test
    public void contextLoads() {
	//
    }
}
